# pageTop

トップに戻るボタンを作成・制御する script。

## 使い方

- bundle
  - es5 でコンパイルしてあるので Internet Explorer でも利用可能です。
  - ボタンのスタイルは変更できません。
  1. `pageTop_bundle.js`を html で読み込む

### 書式

```js
new PageTop(settings);
```
